import { Component } from '@angular/core';

@Component({
  selector: 'app-common-section',
  templateUrl: './common-section.component.html',
  styleUrls: ['./common-section.component.scss']
})
export class CommonSectionComponent {

}
