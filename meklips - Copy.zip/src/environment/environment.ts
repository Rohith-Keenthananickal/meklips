export const environment = {
    // url : 'https://api.meklipsdev.shop'
    url : 'http://localhost:5179'
    

}